//#include "Server.h"
//#include "Client.h"
//
//int main()
//{
//	//Creates class objects necessary for run
//	Server serverObj;
//	Client clientObj;
//	
//	//Asks for whether the user wants to run the client or the server protocol
//	char connectionType;
//	std::cout << "(s) for server, (c) for client: ";
//	std::cin >> connectionType;
//
//	if (connectionType == 's')
//	{
//		serverObj.initialiseServer();
//	}
//	else
//	{
//		clientObj.initialiseClient();
//	}
//}