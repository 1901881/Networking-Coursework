Setup:
1. Open the .exe twice
2. In the command window of the first type s
3. In the command window of the second type c
4. In the client command window type the IP address of the server
5. Server player controls are W,A,S,D (Blue Robot)
6. Client Player controls are the arrow keys (Red Robot)

Aim of the game is to push the box onto the other players side.

GitHub: https://github.com/1901881/Networking-Coursework

How To Link Libraries: https://www.youtube.com/watch?v=YfMQyOw1zik&t=111s

SFML Version Number: 2.5.1

Demo Video MS Stream: https://web.microsoftstream.com/video/ed72f113-3f9f-4de3-92d1-a41af77349be
Demo Video Youtube: https://youtu.be/4tcfm2nRQYQ